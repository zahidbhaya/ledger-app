from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import os
from kivy.utils import platform
from datetime import datetime
from fpdf import FPDF

# --- Android storage fallback ---
try:
    from android.storage import app_storage_path
except ModuleNotFoundError:
    import os
    # On desktop, use current working directory
    def app_storage_path():
        return os.getcwd()

# --- Example function ---
def save_page2_table_as_pdf(filename="page2_table.pdf"):
    path = app_storage_path()
    pdf_path = f"{path}/{filename}"

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, "Hello Page2 Table", ln=1, align="C")
    pdf.output(pdf_path)

    print("PDF saved at:", pdf_path)
    return pdf_path




# ---------------- Helper: Get Downloads folder ----------------
def get_download_path(filename):
    if platform == "android":
        try:
            from android.storage import primary_external_storage_path
            download_folder = os.path.join(primary_external_storage_path(), "Download")
        except ImportError:
            download_folder = os.path.expanduser("~")
        if not os.path.exists(download_folder):
            os.makedirs(download_folder)
        return os.path.join(download_folder, filename)
    else:
        download_folder = os.path.join(os.path.expanduser("~"), "Downloads")
        if not os.path.exists(download_folder):
            os.makedirs(download_folder)
        return os.path.join(download_folder, filename)

# ---------------- Save table as PDF ----------------
def save_page2_table_as_pdf(client_name, client_mobile, ledger, filename=None):
    """
    Save Page2 table data to PDF with unique filename and client header.
    """
    # Generate unique filename if not provided
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{client_name}_{client_mobile}_{timestamp}.pdf"
    filename = filename.replace(" ", "_")  # remove spaces
    filename = get_download_path(filename)

    doc = SimpleDocTemplate(filename, pagesize=A4)
    elements = []

    # Add client name and mobile at top
    styles = getSampleStyleSheet()
    header_text = f"Client: {client_name} ({client_mobile})"
    elements.append(Paragraph(header_text, styles['Heading2']))
    elements.append(Spacer(1, 12))  # space after header

    # Table data
    data = [["Sr", "Date", "Detail", "Amount/hour", "Amount deposited", "Pending"]]

    total_hour = 0
    total_deposit = 0
    for row in ledger:
        data.append(row)
        total_hour += float(row[3])
        total_deposit += float(row[4])

    # Totals row
    data.append(["", "", "Total", str(total_hour), str(total_deposit), str(total_deposit - total_hour)])

    # Create table
    table = Table(data, colWidths=[40, 80, 200, 80, 100, 80])
    style = TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.darkblue),
        ('TEXTCOLOR',(0,0),(-1,0),colors.whitesmoke),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 1, colors.black),
        ('BACKGROUND', (0,1), (-1,-2), colors.whitesmoke),
        ('BACKGROUND', (0,-1), (-1,-1), colors.lightgrey),
        ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
    ])
    table.setStyle(style)
    elements.append(table)

    doc.build(elements)
    print(f"PDF saved successfully: {filename}")
