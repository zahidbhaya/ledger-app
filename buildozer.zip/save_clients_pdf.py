from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
import os


from fpdf import FPDF

# --- Android storage fallback ---
try:
    from android.storage import app_storage_path
except ModuleNotFoundError:
    import os
    # On desktop, use current working directory
    def app_storage_path():
        return os.getcwd()

# --- Example function ---
def save_clients_as_pdf(filename="clients.pdf"):
    path = app_storage_path()
    pdf_path = f"{path}/{filename}"

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, "Hello Clients PDF", ln=1, align="C")
    pdf.output(pdf_path)

    print("PDF saved at:", pdf_path)
    return pdf_path


def get_download_path(filename):
    """Return default Downloads folder path (cross-platform)."""
    home = os.path.expanduser("~")
    download_folder = os.path.join(home, "Downloads")
    if not os.path.exists(download_folder):
        os.makedirs(download_folder)
    return os.path.join(download_folder, filename)

def save_clients_as_pdf(clients, filename="Clients_List.pdf"):
    """
    Save the list of clients to PDF.

    :param clients: Dict of clients {mobile: {'name': name, 'ledger': []}, ...}
    :param filename: PDF filename
    """
    filename = get_download_path(filename)

    doc = SimpleDocTemplate(filename, pagesize=A4)
    elements = []

    data = [["Sr", "Name", "Mobile"]]
    for i, (mobile, data_client) in enumerate(clients.items(), 1):
        data.append([str(i), data_client['name'], mobile])

    table = Table(data, colWidths=[40, 200, 100])
    style = TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.darkblue),
        ('TEXTCOLOR',(0,0),(-1,0),colors.whitesmoke),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 1, colors.black),
    ])
    table.setStyle(style)
    elements.append(table)

    doc.build(elements)
    print(f"PDF saved successfully: {filename}")
